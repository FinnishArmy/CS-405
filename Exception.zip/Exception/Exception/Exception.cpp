// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// Extra required includes
#include <stdexcept>
#include <string>

// Custom Exception
    //  your custom exception
    //  std::exception
    //  uncaught exception
    // source: https://medium.com/@hixcoder/exception-classes-in-c-b57ecc8a7f2d
class MyException : public std::exception
{
public:
    explicit MyException(std::string error) : error_(std::move(error)) {}

    const char* what() const noexcept override
    {
        return error_.c_str();
    }

public:
    std::string error_;
};

bool do_even_more_custom_application_logic()
{

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    // standard exception
    // runtime_error: https://cplusplus.com/reference/stdexcept/runtime_error/
    throw std::runtime_error("Do Even More Custom Application Logic Failure (std::runtime_error).");

    return true;
}
void do_custom_application_logic()
{

    std::cout << "Running Custom Application Logic." << std::endl;

    // we wrap the call to do_even_more_custom_application_logic() in a try-catch
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    } // display message and exception.what()
    catch (const std::exception& err) {
        // cerr: https://cplusplus.com/reference/iostream/cerr/?kw=cerr
        std::cerr << "Handling error std::exception: " << err.what() << std::endl;
    }

    std::cout << "Leaving Custom Application Logic." << std::endl;

    // throw custom exception
    throw MyException("Custom Exception Error (MyException).");

}

float divide(float num, float den)
{
    // check for the final value, then throw an exception if needed
    if (den == 0.0f)
    {
        throw std::domain_error("Devide by zero (std::domain_error).");
    }
    return (num / den);
}

void do_division() noexcept
{
    float numerator = 10.0f;
    float denominator = 0;

    // use try-catch block to only catch devide by zero
    try 
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& err) 
    {
        std::cerr << "Handling std::domain_error: " << err.what() << std::endl;
    }

}

int main() try
{
    std::cout << "Exceptions Tests!" << std::endl;

    do_division();
    do_custom_application_logic();

    return 0;
}
// How to catch all
// source: https://stackoverflow.com/questions/315948/c-catching-all-exceptions

// catch my exception
catch (const MyException& err) {
    std::cerr << "Main MyException error: " << err.what() << std::endl;
    return 1;
}

// then std::exception
catch (const std::exception& err) {
    std::cerr << "Main std::exception error: " << err.what() << std::endl;
    return 2;
}

// then a catch all (unknown error)
catch (...) {
    std::cerr << "Main unknown exception occurred." << std::endl;
    return 3;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
