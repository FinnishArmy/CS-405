// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits> // Numerical limits
#include <cctype> // Check for spaces

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;


  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";

  // After the user inputs the data, we can then cleanse it.

  // Read up to 19 characters, then flush the rest.

  // setw: https://cplusplus.com/reference/iomanip/setw/
  std::cin >> std::setw(sizeof(user_input)) >> user_input;

  // Flag
  bool flush = false;
  int next = std::cin.peek();
  // Keep reading until the next char is space
  if (next != EOF && !std::isspace(static_cast<unsigned char>(next))) {
	  // This means we hit the buffer limit
	  flush = true;
	  // Notify the caller
	  return EXIT_FAILURE;
  }

  // Always flush after buffer to prevent errors
  std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');


  if (flush) {
      std::cout << "Input too long; flushing to 20 char." << std::endl;
  }

  // Safegaurd completed.
  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
  // Notify the caller
  return EXIT_SUCCESS;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
